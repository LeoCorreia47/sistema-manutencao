package br.net.manutencao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaManutencaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
