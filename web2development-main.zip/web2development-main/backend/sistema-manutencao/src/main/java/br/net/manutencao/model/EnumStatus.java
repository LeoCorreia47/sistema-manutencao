package br.net.manutencao.model;

public enum EnumStatus {
    ORÇADA,
    APROVADA,
    REJEITADA,
    ARRUMADA,
    ABERTA,
    REDIRECIONADA,
    PAGA,
    FINALIZADA
}