package br.net.manutencao.DTO;

import lombok.Data;

@Data
public class ManutencaoDTO {
    private String descricaoManutencao;
    private String orientacoesCliente;
}
