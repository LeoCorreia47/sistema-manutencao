export class Categoria {
    constructor( 
        public id: number = 0,
        public nome: string = "",){}
}
